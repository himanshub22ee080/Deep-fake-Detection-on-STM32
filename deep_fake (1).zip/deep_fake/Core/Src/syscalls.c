#include <sys/stat.h>
#include <sys/types.h>
#include <unistd.h>
#include <errno.h>

int _write(int file, char *ptr, int len) {
    // Redirect printf to nothing or to UART later
    return len;
}

int _read(int file, char *ptr, int len) {
    errno = EBADF;
    return -1;
}

int _close(int file) {
    return -1;
}

int _fstat(int file, struct stat *st) {
    st->st_mode = S_IFCHR;
    return 0;
}

int _isatty(int file) {
    return 1;
}

int _lseek(int file, int ptr, int dir) {
    return 0;
}
