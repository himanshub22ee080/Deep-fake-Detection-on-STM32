#include "main.h"
#include "ai_platform.h"
#include "deep.h"
#include "deep_data.h"

// ---------------- Manual Definitions (If deep_data.h is incomplete) ----------------
#define AI_DEEP_DATA_INPUT_SIZE         (96 * 96 * 3)
#define AI_DEEP_DATA_OUTPUT_SIZE        1
// -----------------------------------------------------------------------------------

// Dummy input image: all pixels set to 0.5 (normalized RGB)
AI_ALIGNED(4) static uint8_t input_data[AI_DEEP_DATA_INPUT_SIZE] = { [0 ... (AI_DEEP_DATA_INPUT_SIZE - 1)] = 50 };

//#define AI_DEEP_DATA_INPUT_SIZE (96 * 96 * 3)
// AI output buffer
AI_ALIGNED(4) static uint8_t output_data[AI_DEEP_DATA_OUTPUT_SIZE];

// AI instance and buffers
static ai_handle deep_model = AI_HANDLE_NULL;
AI_ALIGNED(4) static ai_u8 activations[AI_DEEP_DATA_ACTIVATIONS_SIZE];

static ai_buffer *ai_input;
static ai_buffer *ai_output;

// Function prototypes
void SystemClock_Config(void);
static void MX_GPIO_Init(void);
void Error_Handler(void);

int main(void)
{
    HAL_Init();
    SystemClock_Config();
    MX_GPIO_Init();

    // ----------------- X-CUBE-AI INIT -----------------
    ai_error err = ai_deep_create(&deep_model, AI_DEEP_DATA_CONFIG);
    if (err.type != AI_ERROR_NONE) {
        Error_Handler();
    }

    const ai_network_params params = {
        .activations = {
            .format = AI_BUFFER_FORMAT_U8,
            .size   = AI_DEEP_DATA_ACTIVATIONS_SIZE,
            .data   = activations
        },
        .params = AI_DEEP_DATA_WEIGHTS(ai_deep_data_weights_get())
    };

    if (!ai_deep_init(deep_model, &params)) {
        Error_Handler();
    }

    ai_input = ai_deep_inputs_get(deep_model, NULL);
    ai_output = ai_deep_outputs_get(deep_model, NULL);

    ai_input[0].data = input_data;
    ai_output[0].data = output_data;

    // ----------------- Inference -----------------
    if (ai_deep_run(deep_model, ai_input, ai_output) != 1) {
        Error_Handler();
    }

    //float prediction = output_data[0];
    float prediction = ((float)output_data[0]) * 0.00390625f;  // dequantize

    // ----------------- Output via GPIO -----------------
    if (prediction > 0.5f) {
        // Real → PG13 ON, PG14 OFF
        HAL_GPIO_WritePin(GPIOG, GPIO_PIN_13, GPIO_PIN_SET);
        HAL_GPIO_WritePin(GPIOG, GPIO_PIN_14, GPIO_PIN_RESET);
    } else {
        // Deepfake → PG14 ON, PG13 OFF
        HAL_GPIO_WritePin(GPIOG, GPIO_PIN_14, GPIO_PIN_SET);
        HAL_GPIO_WritePin(GPIOG, GPIO_PIN_13, GPIO_PIN_RESET);
    }

    // ----------------- Optional Blink -----------------
//    while (1) {
//        HAL_Delay(1000);
//        HAL_GPIO_TogglePin(GPIOG, (prediction > 0.5f) ? GPIO_PIN_14 : GPIO_PIN_13);
//    }
}

// ----------------- GPIO Init (PG13 & PG14) -----------------
static void MX_GPIO_Init(void)
{
    __HAL_RCC_GPIOG_CLK_ENABLE();

    GPIO_InitTypeDef GPIO_InitStruct = {0};
    GPIO_InitStruct.Pin = GPIO_PIN_13 | GPIO_PIN_14;
    GPIO_InitStruct.Mode = GPIO_MODE_OUTPUT_PP;
    GPIO_InitStruct.Pull = GPIO_NOPULL;
    GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_LOW;
    HAL_GPIO_Init(GPIOG, &GPIO_InitStruct);
}

// ----------------- Dummy Clock Config (use STM32CubeMX one if needed) -----------------
void SystemClock_Config(void)
{
    RCC_OscInitTypeDef RCC_OscInitStruct = {0};
    RCC_ClkInitTypeDef RCC_ClkInitStruct = {0};
    RCC_PeriphCLKInitTypeDef PeriphClkInitStruct = {0};

    /** Configure the main internal regulator output voltage */
    __HAL_RCC_PWR_CLK_ENABLE();
    __HAL_PWR_VOLTAGESCALING_CONFIG(PWR_REGULATOR_VOLTAGE_SCALE1);

    /** Initializes the RCC Oscillators according to the specified parameters */
    RCC_OscInitStruct.OscillatorType = RCC_OSCILLATORTYPE_HSE;
    RCC_OscInitStruct.HSEState = RCC_HSE_ON;
    RCC_OscInitStruct.PLL.PLLState = RCC_PLL_ON;
    RCC_OscInitStruct.PLL.PLLSource = RCC_PLLSOURCE_HSE;
    RCC_OscInitStruct.PLL.PLLM = 8;
    RCC_OscInitStruct.PLL.PLLN = 360;
    RCC_OscInitStruct.PLL.PLLP = RCC_PLLP_DIV2;
    RCC_OscInitStruct.PLL.PLLQ = 7;

    if (HAL_RCC_OscConfig(&RCC_OscInitStruct) != HAL_OK)
    {
        Error_Handler();
    }

    /** Initializes the CPU, AHB and APB buses clocks */
    RCC_ClkInitStruct.ClockType = RCC_CLOCKTYPE_HCLK | RCC_CLOCKTYPE_SYSCLK
                                  | RCC_CLOCKTYPE_PCLK1 | RCC_CLOCKTYPE_PCLK2;
    RCC_ClkInitStruct.SYSCLKSource = RCC_SYSCLKSOURCE_PLLCLK;
    RCC_ClkInitStruct.AHBCLKDivider = RCC_SYSCLK_DIV1;
    RCC_ClkInitStruct.APB1CLKDivider = RCC_HCLK_DIV4;
    RCC_ClkInitStruct.APB2CLKDivider = RCC_HCLK_DIV2;

    if (HAL_RCC_ClockConfig(&RCC_ClkInitStruct, FLASH_LATENCY_5) != HAL_OK)
    {
        Error_Handler();
    }

    /** Configure peripheral clocks if needed */
    PeriphClkInitStruct.PeriphClockSelection = RCC_PERIPHCLK_I2S;
    PeriphClkInitStruct.PLLI2S.PLLI2SN = 192;
    PeriphClkInitStruct.PLLI2S.PLLI2SR = 5;
    if (HAL_RCCEx_PeriphCLKConfig(&PeriphClkInitStruct) != HAL_OK)
    {
        Error_Handler();
    }
}



// ----------------- Error Handler -----------------
void Error_Handler(void)
{
    // Blink both PG13 and PG14 quickly to indicate error
    while (1) {
        HAL_GPIO_TogglePin(GPIOG, GPIO_PIN_13 | GPIO_PIN_14);
        HAL_Delay(200);
    }
}
